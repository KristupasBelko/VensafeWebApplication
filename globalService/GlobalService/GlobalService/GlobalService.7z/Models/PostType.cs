﻿namespace GlobalService.Models
{
    public class PostType
    {
        public object[] Products { get; set; }
        public string StoreId { get; set; }
    }
}
