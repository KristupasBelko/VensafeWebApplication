﻿
namespace GlobalService.Models
{
    public class Store  
    {
        public int Id { get; set; }
        public string StoreId { get; set; }
        public string ProductsServiceLink { get; set; }
        public string SalesApiLink { get; set; }
    }
}
